// ============================================================
// COCICP Gastos — Worker Cloudflare
// 3 agentes en paralelo con Promise.all()
// Bindings: DB (D1) | BUCKET (R2) | ANTHROPIC_API_KEY (secret)
// ============================================================

import { runAgent1 } from './agent1-fiscal.js';
import { runAgent2 } from './agent2-provider.js';
import { runAgent3 } from './agent3-classification.js';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Content-Type': 'application/json'
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: CORS });
}

// ── Merge de los 3 resultados ────────────────────────────────
function mergeAgents(a1, a2, a3, usuario) {
  const errores = [a1, a2, a3]
    .filter(a => a.error)
    .map(a => `Agente ${a.agent}: ${a.error}`);

  const nit = a2.emisor?.nit || null;
  const nitSinDv = a2.emisor?.nit_sin_dv || null;
  const nombreProveedor = a2.catalogo_match?.nombre_corto
    || a2.emisor?.nombre_comercial
    || a2.emisor?.razon_social
    || 'Proveedor desconocido';

  const categoria = a3.categoria
    || a2.catalogo_match?.categoria_default
    || 'Misceláneos';

  const confianzaMap = { alta: 3, media: 2, baja: 1 };
  const confianzaMin = Math.min(
    confianzaMap[a1.confianza] || 1,
    confianzaMap[a2.confianza] || 1,
    confianzaMap[a3.confianza] || 1
  );
  const confianza = Object.keys(confianzaMap).find(k => confianzaMap[k] === confianzaMin);
  const estado = (confianza === 'baja' || errores.length > 0) ? 'revision' : 'confirmado';

  return {
    proveedor_nit:            nit,
    proveedor_nit_sin_dv:     nitSinDv,
    proveedor_nombre:         nombreProveedor,
    proveedor_razon_social:   a2.emisor?.razon_social || null,
    en_catalogo:              !!a2.catalogo_match,
    numero_documento:         a1.numero_documento || null,
    tipo_documento:           a1.tipo_documento || 'otro',
    es_documento_electronico: a2.es_documento_electronico || false,
    cufe_cude:                a2.cufe_cude || null,
    fecha:                    a1.fecha_pago || a1.fecha_emision || null,
    fecha_emision:            a1.fecha_emision || null,
    categoria,
    concepto:                 a3.concepto || 'Sin concepto',
    deducible_cocicp:         a3.deducible_cocicp ?? true,
    es_viatico:               a3.es_viatico || false,
    municipio_gasto:          a3.municipio_gasto || null,
    valor_base:               a1.valores?.subtotal || 0,
    iva:                      a1.valores?.iva || 0,
    inc:                      a1.valores?.inc || 0,
    otros_impuestos:          (a1.valores?.impo_consumo || 0) + (a1.valores?.otros_impuestos || 0),
    descuentos:               a1.valores?.descuentos || 0,
    total:                    a1.valores?.total || 0,
    es_nota_credito:          a1.es_nota_credito || false,
    moneda:                   a1.moneda || 'COP',
    medio_pago:               a1.medio_pago || null,
    referencia_pago:          a1.referencia_pago || null,
    usuario,
    estado,
    confianza_global:         confianza,
    errores_parciales:        errores.length > 0 ? errores : null,
    notas:                    a3.notas_clasificacion || null,
    _agents_raw:              { a1, a2, a3 }
  };
}

async function checkDuplicate(db, numeroDocumento, total) {
  if (!numeroDocumento || !db) return false;
  const row = await db.prepare(
    'SELECT id FROM gastos WHERE numero_documento = ? OR (ABS(total - ?) < 1 AND fecha > date("now", "-7 days"))'
  ).bind(numeroDocumento, total).first();
  return !!row;
}

// ═══════════════════════════════════════════════════════════
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });

    // ── POST /api/upload ────────────────────────────────────
    if (request.method === 'POST' && url.pathname === '/api/upload') {
      try {
        const form    = await request.formData();
        const file    = form.get('file');
        const usuario = form.get('usuario') || 'david';
        if (!file) return json({ error: 'No file' }, 400);

        const mimeType = file.type;
        const buf      = await file.arrayBuffer();
        const b64      = btoa(String.fromCharCode(...new Uint8Array(buf)));

        const r2Key     = `soportes/${Date.now()}-${file.name}`;
        const r2Promise = env.BUCKET.put(r2Key, buf, { httpMetadata: { contentType: mimeType } });

        // ★ 3 agentes simultáneos
        const [a1, a2, a3] = await Promise.all([
          runAgent1(b64, mimeType),
          runAgent2(b64, mimeType, env.DB),
          runAgent3(b64, mimeType)
        ]);

        await r2Promise;

        const preview = mergeAgents(a1, a2, a3, usuario);
        preview.archivo_r2 = r2Key;
        preview.es_posible_duplicado = await checkDuplicate(env.DB, preview.numero_documento, preview.total);

        return json({ ok: true, preview });
      } catch (err) {
        return json({ error: err.message }, 500);
      }
    }

    // ── POST /api/confirm ───────────────────────────────────
    if (request.method === 'POST' && url.pathname === '/api/confirm') {
      try {
        const body   = await request.json();
        const maxRow = await env.DB.prepare('SELECT MAX(numero) as max FROM gastos').first();
        const numero = (maxRow?.max || 0) + 1;

        await env.DB.prepare(`
          INSERT INTO gastos
            (numero, fecha, proveedor_nit, proveedor_nombre, numero_documento,
             concepto, categoria, valor_base, iva, inc, otros_impuestos,
             total, es_nota_credito, medio_pago, referencia_pago,
             archivo_r2, usuario, estado, notas)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        `).bind(
          numero, body.fecha, body.proveedor_nit, body.proveedor_nombre,
          body.numero_documento, body.concepto, body.categoria,
          body.valor_base || 0, body.iva || 0, body.inc || 0,
          body.otros_impuestos || 0, body.total,
          body.es_nota_credito ? 1 : 0,
          body.medio_pago, body.referencia_pago,
          body.archivo_r2, body.usuario || 'david',
          body.estado || 'confirmado', body.notas || null
        ).run();

        return json({ ok: true, numero }, 201);
      } catch (err) {
        return json({ error: err.message }, 500);
      }
    }

    // ── GET /api/gastos ─────────────────────────────────────
    if (request.method === 'GET' && url.pathname === '/api/gastos') {
      const p     = url.searchParams;
      const desde = p.get('desde') || '2026-01-01';
      const hasta = p.get('hasta') || '2026-12-31';
      const cat   = p.get('categoria');

      let q = 'SELECT * FROM gastos WHERE fecha BETWEEN ? AND ?';
      let v = [desde, hasta];
      if (cat) { q += ' AND categoria = ?'; v.push(cat); }
      q += ' ORDER BY fecha DESC, id DESC';

      const result = await env.DB.prepare(q).bind(...v).all();
      const total  = result.results.reduce((s, r) => s + r.total, 0);
      const porCategoria = result.results.reduce((acc, r) => {
        acc[r.categoria] = (acc[r.categoria] || 0) + r.total;
        return acc;
      }, {});

      return json({ registros: result.results, total_registros: result.results.length, gran_total: total, por_categoria: porCategoria });
    }

    return json({ error: 'Not found' }, 404);
  }
};
